import ListaProdutos from './componentes/ListaProdutos.jsx';
import './App.css';


function App() {
  return (
    <div className="Principal">
      <ListaProdutos />
    </div>
  );
}

export default App;
